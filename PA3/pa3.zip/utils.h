#ifndef UTILS_HEADER
#define UTILS_HEADER

int max(int a, int b);
int is_power_of_2(int n);

#endif