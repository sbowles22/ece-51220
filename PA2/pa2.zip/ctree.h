#ifndef CTREE_HEADER
#define CTREE_HEADER

typedef struct _Onode {
    int h;
    int w;

    // Placement
    struct _Tnode* ctnode; 
    int x;
    int y;
    struct _Onode* left;
    struct _Onode* right;
} Option;

typedef struct _OLnode {
    struct _OLnode* next;
    Option* option;
} OptionList;

typedef enum {
    VERTICAL, HORIZONTAL, BLOCK, NONE
} CutType;

typedef struct _Tnode {
    int id;
    CutType type;

    struct _Tnode* left;
    struct _Tnode* right;

    OptionList* options;
} CTree;

typedef struct _CTLnode {
    struct _CTLnode* next;
    CTree* root;
} CTreeList;

typedef struct {
    CTreeList* head;
} CTreeStack;

void ol_destruct(OptionList* ol);
OptionList* ol_node_create(Option* option);
OptionList* ol_pareto_filter(OptionList* ol);
OptionList* ol_sort_by_width(OptionList* ol);
OptionList* ol_destroy_node(OptionList* ol, OptionList* p, OptionList* q);
Option* option_create(int w, int h, CTree* ctnode);

#ifdef DEBUG
void ol_print(OptionList* head);
#endif

CTree* ct_create_node(void);
void ct_destruct(CTree* head);

#ifdef DEBUG
void ct_print(CTree* head);
#endif

void ctl_destruct(CTreeList* ctl);

CTreeStack* ct_stack_create(void);
void ct_stack_destruct(CTreeStack* cts);

int ct_stack_is_empty(CTreeStack* cts);
void ct_stack_push(CTreeStack* cts, CTree* root);
CTree* ct_stack_pop(CTreeStack* cts);

#endif
