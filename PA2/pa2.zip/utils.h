#ifndef UTILS_HEADER
#define UTILS_HEADER

int max(int a, int b);

#endif