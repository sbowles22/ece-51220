#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include "ctree.h"
#include "math.h"

/////////////////
// OPTION LIST //
/////////////////

void ol_destruct(OptionList* ol) {
    OptionList* next;
    while (ol != NULL) {
        next = ol -> next;
        free(ol -> option);
        free(ol);
        ol = next;
    }
}

OptionList* ol_node_create(Option* option) {
    OptionList* node = malloc(sizeof(OptionList));
    if (node == NULL) {
        return NULL;
    }

    node -> next = NULL;
    node -> option = option;

    return node;
}

Option* option_create(int w, int h, CTree* ctnode) {
    Option* op = malloc(sizeof(Option));
    if (op == NULL) {
        return NULL;
    }

    op -> w = w;
    op -> h = h;

    op -> ctnode = ctnode;
    op -> x = INT_MIN;
    op -> y = INT_MIN;
    op -> left = NULL;
    op -> right = NULL;

    return op;
}

OptionList* ol_pareto_filter(OptionList* ol) {
    if (ol == NULL) {
        return NULL;
    }

    ol = ol_sort_by_width(ol);

    int h_filter = ol -> option -> h;
    OptionList* p = ol;
    OptionList* q = ol -> next;
    while (q != NULL) {
        if (q -> option -> h >= h_filter) {
            ol = ol_destroy_node(ol, p, q);
            q = p;
        }
        if (q -> option -> h < h_filter) {
            h_filter = q -> option -> h;
        }

        p = q;
        q = q -> next;
    }

    return ol;
}

OptionList* ol_sort_by_width(OptionList* ol) {
    // Insertion sort
    if (ol == NULL) {
        return NULL;
    }

    if (ol -> next == NULL) {
        return ol;
    }

    OptionList* ol_sorted = ol;
    ol = ol -> next;
    ol_sorted -> next = NULL;

    OptionList* i;
    OptionList* p;
    OptionList* q;
    int inserted;
    while (ol != NULL) {
        inserted = 0;
        i = ol;
        ol = ol -> next;
        if (i -> option -> w <= ol_sorted -> option -> w) {
            i -> next = ol_sorted;
            ol_sorted = i;
            inserted = 1;
        }
        
        p = ol_sorted;
        q = ol_sorted -> next;
        while (!inserted) {
            if (i -> option -> w >= p -> option -> w) {
                p -> next = i;
                i -> next = q;
                inserted = 1;
            }
        }
    }

    return ol_sorted;
}

OptionList* ol_destroy_node(OptionList* ol, OptionList* p, OptionList* q) {
    if (q == NULL) {
        return ol;
    }
    
    if (p != NULL) {
        p -> next = q -> next;
    }
    if (q == ol) {
        ol = q -> next;
    }

    free(q -> option);
    free(q);

    return ol;
}

#ifdef DEBUG
void ol_print(OptionList* head) {
    if (head == NULL) {
        return;
    }

    printf("(%2d,%2d)", head -> option -> w, head -> option -> h);
    if (head -> next != NULL) {
        printf(", ");
    }

    ol_print(head -> next);
}
#endif

/////////////////////
// CONSTRAINT TREE //
/////////////////////

CTree* ct_create_node(void) {
    CTree* node = malloc(sizeof(CTree));
    if (node == NULL) {
        return NULL;
    }

    node -> id = 0;
    node -> type = NONE;
    node -> left = NULL;
    node -> right = NULL;
    node -> options = NULL;

    return node;
}

void ct_destruct(CTree* head) {
    if (head == NULL) {
        return;
    }

    ol_destruct(head -> options);
    
    ct_destruct(head -> left);
    ct_destruct(head -> right);
    free(head);
}

#ifdef DEBUG
void ct_print(CTree* head) {
    if (head == NULL) {
        return;
    }

    switch (head -> type) {
        case VERTICAL:      printf("%4d | V, L: %4d, R: %4d\n", 
                                head -> id, head -> left -> id, head -> right -> id);
                            break;
        case HORIZONTAL:    printf("%4d | H, L: %4d, R: %4d\n", 
                                head -> id, head -> left -> id, head -> right -> id);
                            break;
        case BLOCK:         printf("%4d | B, ", head -> id);
                            ol_print(head -> options);
                            printf("\n");
                            break;
        case NONE:          printf("ERROR, None constraint node detected\n");
    }

    ct_print(head -> left);
    ct_print(head -> right);
}
#endif

//////////////////////////
// CONSTRAINT TREE LIST //
//////////////////////////

void ctl_destruct(CTreeList* ctl) {
    CTreeList* next;
    while (ctl != NULL) {
        next = ctl -> next;
        ct_destruct(ctl -> root);
        free(ctl);
        ctl = next;
    }
}

///////////////////////////
// CONSTRAINT TREE STACK //
///////////////////////////

CTreeStack* ct_stack_create(void) {
    CTreeStack* cts = malloc(sizeof(CTreeStack));
    if (cts == NULL) {
        return NULL;
    }

    cts -> head = NULL;

    return cts;
}

void ct_stack_destruct(CTreeStack* cts) {
    ctl_destruct(cts -> head);
    free(cts); 
}

int ct_stack_is_empty(CTreeStack* cts) {
    return (cts -> head) == NULL;
}

void ct_stack_push(CTreeStack* cts, CTree* root) {
    CTreeList* new = malloc(sizeof(CTreeList));
    // TODO: Possible memory error

    new -> next = cts -> head;
    new -> root = root;

    cts -> head = new;
}

CTree* ct_stack_pop(CTreeStack* cts) {
    CTreeList* node = cts -> head;
    CTree* ct = node -> root;

    cts -> head = node -> next;
    free(node);

    return ct;
}
