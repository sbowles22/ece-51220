#include <stdlib.h>
#include <stdio.h>
#include "layout.h"
#include "ctree.h"
#include "utils.h"

Layout* layout_create(void) {
    Layout* layout = malloc(sizeof(Layout));
    if (layout == NULL) {
        return NULL;
    }

    layout -> ct = NULL;
    layout -> optimal = NULL;

    return layout;
}

void layout_destruct(Layout* lout) {
    if (lout == NULL) {
        return;
    }

    ct_destruct(lout -> ct);

    free(lout);
}

int layout_no_choice(Layout* layout) {
    CTreeStack* cts_temp = ct_stack_create();
    if (cts_temp == NULL) {
        return -1;
    }
    
    CTreeStack* cts = ct_stack_create();
    if (cts_temp == NULL) {
        return -1;
    }

    // Find leftmost block node for traversal
    CTree* first = layout -> ct;
    while (first -> left != NULL) {
        first = first -> left;
    }

    // Consider its placement [bottom left] as (0,0)
    first -> options -> option -> x = 0;
    first -> options -> option -> y = 0;

    // Add all nodes to stack
    CTree* node;
    ct_stack_push(cts_temp, layout -> ct);
    while (!ct_stack_is_empty(cts_temp)) {
        node = ct_stack_pop(cts_temp);
        if (node -> type == VERTICAL || node -> type == HORIZONTAL) {
            ct_stack_push(cts_temp, node -> left);
            ct_stack_push(cts_temp, node -> right);
        }
        ct_stack_push(cts, node);
    }

    ct_stack_destruct(cts_temp);

    // cts now has all nodes in post-order fashion
    int w;
    int h;
    Option* option;

    while (!ct_stack_is_empty(cts)) {
        node = ct_stack_pop(cts);
        switch (node -> type) {
        case VERTICAL:      w = (node -> left -> options -> option -> w) + (node -> right -> options -> option -> w);
                            h = max(node -> left -> options -> option -> h, node -> right -> options -> option -> h);
                            option = option_create(w, h, node);

                            option -> x = node -> left -> options -> option -> x + node -> left -> options -> option -> w;
                            option -> y = node -> left -> options -> option -> y;
                            option -> left = node -> left -> options -> option;
                            option -> right = node -> right -> options -> option;

                            node -> options = ol_node_create(option);
                            break;
        case HORIZONTAL:    w = max(node -> left -> options -> option -> w, node -> right -> options -> option -> w);
                            h = (node -> left -> options -> option -> h) + (node -> right -> options -> option -> h);
                            option = option_create(w, h, node);

                            option -> x = node -> left -> options -> option -> x;
                            option -> y = node -> left -> options -> option -> y + node -> left -> options -> option -> h;
                            option -> left = node -> left -> options -> option;
                            option -> right = node -> right -> options -> option;

                            node -> options = ol_node_create(option);
                            break;
        default:            break;
        }
    }
    ct_stack_destruct(cts);

    layout -> optimal = layout -> ct -> options -> option;
    return 0;
}

int layout_with_choice(Layout* layout) {
    CTreeStack* cts_temp = ct_stack_create();
    if (cts_temp == NULL) {
        return -1;
    }
    
    CTreeStack* cts = ct_stack_create();
    if (cts_temp == NULL) {
        return -1;
    }

    // Find leftmost block node for traversal
    CTree* first = layout -> ct;
    while (first -> left != NULL) {
        first = first -> left;
    }

    // Consider its placement [bottom left] as (0,0)
    first -> options -> option -> x = 0;
    first -> options -> option -> y = 0;

    // Add all nodes to stack
    CTree* node;
    ct_stack_push(cts_temp, layout -> ct);
    while (!ct_stack_is_empty(cts_temp)) {
        node = ct_stack_pop(cts_temp);
        if (node -> type == VERTICAL || node -> type == HORIZONTAL) {
            ct_stack_push(cts_temp, node -> left);
            ct_stack_push(cts_temp, node -> right);
        }
        ct_stack_push(cts, node);
    }

    ct_stack_destruct(cts_temp);

    // cts now has all nodes in post-order fashion
    int w;
    int h;
    Option* option;
    OptionList* ol_new_head;

    while (!ct_stack_is_empty(cts)) {
        node = ct_stack_pop(cts);
        switch (node -> type) {
        case VERTICAL:

        for (OptionList* left_op = node -> left -> options; left_op != NULL; left_op = left_op -> next) {
            for (OptionList* right_op = node -> right -> options; right_op != NULL; right_op = right_op -> next) {
                w = (left_op -> option -> w) + (right_op -> option -> w);
                h = max(left_op -> option -> h, right_op -> option -> h);
                option = option_create(w, h, node);

                option -> x = left_op -> option -> x + left_op -> option -> w;
                option -> y = left_op -> option -> y;
                option -> left = left_op -> option;
                option -> right = right_op -> option;

                ol_new_head = ol_node_create(option);
                ol_new_head -> next = node -> options;
                node -> options = ol_new_head;
            }
        }
        node -> options = ol_pareto_filter(node -> options);

                            break;
        case HORIZONTAL:    
        
        for (OptionList* left_op = node -> left -> options; left_op != NULL; left_op = left_op -> next) {
            for (OptionList* right_op = node -> right -> options; right_op != NULL; right_op = right_op -> next) {
                w = max(left_op -> option -> w, right_op -> option -> w);
                h = (left_op -> option -> h) + (right_op -> option -> h);
                option = option_create(w, h, node);

                option -> x = left_op -> option -> x;
                option -> y = left_op -> option -> y + left_op -> option -> h;
                option -> left = left_op -> option;
                option -> right = right_op -> option;

                ol_new_head = ol_node_create(option);
                ol_new_head -> next = node -> options;
                node -> options = ol_new_head;
            }
        }
        node -> options = ol_pareto_filter(node -> options);

                            break;
        default:            break;
        }
    }
    ct_stack_destruct(cts);

#ifdef DEBUG
    ol_print(layout -> ct -> options);
    printf("\n");
#endif

    // Determine Optimal Layout by Minimum Area
    layout -> optimal = layout -> ct -> options -> option;
    long optimal_area = layout -> optimal -> w * layout -> optimal -> h;
    for (OptionList* q = layout -> ct -> options; q != NULL; q = q -> next) {
        if (q -> option -> w * q -> option -> h < optimal_area) {
            layout -> optimal = q -> option;
            optimal_area = q -> option -> w * q -> option -> h;
        }
    }  

    return 0;
}
